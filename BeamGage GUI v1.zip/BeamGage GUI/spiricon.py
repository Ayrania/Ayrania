# -*- coding: utf-8 -*-
"""
Created on Wed Jul 19 21:07:16 2023

@author: ayras
"""
import clr #needs 2.5.2
import sys, time, threading
from threading import Thread
import atexit
import numpy as np
from abc import abstractmethod, ABC
from PIL import Image

import matplotlib.pyplot as plt

def add_NET_dll(file):
    name = file.rfind("/")
    if name:
        name = file[name+1:]
    else:
        name = file
    try:
        print("Loading %s" % name)
        print("\t%s" % clr.AddReference(name))
    except:
        print("Could not load: %s" % name)
        raise
    return


#Load .net dll for eamGauge
file = __file__
ind = max(file.rfind("/"),file.rfind("\\"))
file = file[0:ind+1]
dll_path = file + "lib/"
print("Adding to path: %s" % dll_path)
sys.path.append(dll_path)
#add_NET_dll("Spiricon.BeamMic.Automation")
add_NET_dll("Spiricon.BeamGage.automation")
from Spiricon.Automation import *

# needed for grabbing the C# array for images
add_NET_dll("System")
add_NET_dll("System.Runtime")
add_NET_dll("System.Runtime.InteropServices")
from System.Runtime.InteropServices import Marshal
from System import UInt64, Int64, IntPtr, String

class Camera(ABC):
    @abstractmethod
    def start(self):
        pass
    @abstractmethod
    def stop(self):
        pass
    
    @abstractmethod
    def get_image(self):
        pass
    
    @abstractmethod
    def get_nextimage(self):
        pass
    
    @property
    @abstractmethod
    def width(self):
        pass
    
    @property
    @abstractmethod
    def pixel_lim(self):
        pass
    
    @property
    @abstractmethod
    def pixel_scale(self):
        pass
    
class Spiricon(Camera):
    @abstractmethod
    def __init__(self):
        pass
    
    def set_source(self, source_name):
        #check if source is available
        available = self.get_source_list()
        if source_name not in available:
            print("Could not find %s"% source_name)
            print("Available sources:")
            for i in range(available.Length):
                print("\t%s" % available[i])
            self.close()
            
            s = "Desired source unavailable. \nIs camera plugged in and licensed?"
            raise ValueError(s)
            
        # Set new source
        self.camera.DataSource.DataSource = source_name
        self.source_name = source_name
        return
    
    @property
    def width(self):
        return self.camera.ResultsPriorityFrame.Width
    
    @property
    def height(self):
        return self.camera.ResultsPriorityFrame.Height
    
    def get_nextimage(self):
        return self.get_image()
    
    @property
    def pixel_lim(self):
        source_name = getattr(self, "source_name", None)
        if "SP928" in source_name:
            return [0,2**12]
        
        return None
    
    @property
    def pixel_scale(self):
        source_name = getattr(self, "source_name", None)
        # print('Source Name=',source_name)
        if "SP928" in source_name:
            return 3.69e-6
        if "LW1050" in source_name:
            return 9e-6
        return None
    
    def get_source_list(self):
        source_list = self.camera.DataSource.DataSourceList
        return source_list
    
    def close(self):
        self.camera.Instance.Shutdown()
        atexit.unregister(self.close)
        return
    
    def start(self):
        self.camera.DataSource.Start()
        return
    
    def stop(self):
        self.camera.DataSource.Stop()
        return
    
    def ultracal(self):
        self.camera.Calibration.Ultracal()
        start = time.time()
        print("Starting ultracal...")
        time.sleep(1)
        while self.camera.Calibration.Status != 3:
            time.sleep(.1)
        print("Ultracal done")
        
        return
    
    def autox(self):
        return self.camera.Calibration.AutoX()
    
    def get_exposure(self):
        return self.camera.EGB.Get(EGBDesignator.EXPOSURE)
    def get_gain(self):
        return self.camera.EGB.Get(EGBDesignator.GAIN, val)
    def get_blacklevel(self):
        return self.camera.EGB.Get(EGBDesignator.BLACKLEVEL, val)
    
    def snap(self, func=None):
        self.wait_one_frame()
        self.stop()
        if func is not None:
            func()
        return
    
    def wait_one_frame(self, max_wait = 10., func=None):
        exp_time = self.get_exposure()
        
        last_frame = self.camera.FrameBuffer.Current
        #self.start()
        start_time = time.time()
        for i in range(2):
            while last_frame == self.camera.FrameBuffer.Current:
                time.sleep(exp_time*1e-3*.5)
                if (time.time()-start_time) > max_wait:
                    raise RuntimeError("Timeout waiting for new frame from camera.")
            if func is not None: 
                func()
            return
        
    def get_image(self,dtype=int):
        if dtype == int:
            src = self.camera.ResultsPriorityFrame.FrameData
            dest = np.empty(len(src),dtype=np.int32)
        else:
            src = self.camera.ResultsPriorityFrame.DoubleData
            dest = np.empty(len(src), dtype=flat)
        Marshal.Copy(src,0,IntPtr.__overloads__[Int64](dest.__array_interface__['data'][0]), len(src))
        if dtype == int:
            dest = (dest-np.amin(dest))
            dest = 255*(dest/np.amax(dest))
        return dest.reshape((self.height, self.width))
    
    def save_image(self, file):
        if ".bmdata" in file or ".bGdata" in file:
            self.camera.SaveLoadData.SaveData(String(file), \
                                                     UInt64(self,camera.FrameBuffer.Current), \
                                                         UInt64(1))
            return
        else:
            im = self.get_image()
            im = Image.fromarray(im.astype(np.int32))
            im.save(file)
            return
        
    def get_image(self,dtype=int):
        if dtype == int:
            src = self.camera.ResultsPriorityFrame.FrameData
            dest = np.empty(len(src),dtype=np.int32)
        else:
            src = self.camera.ResultsPriorityFrame.DoubleData
            dest = np.empty(len(src), dtype=float)
        Marshal.Copy(src,0,IntPtr.__overloads__[Int64](dest.__array_interface__['data'][0]),len(src))
        if dtype == int:
            dest = (dest-np.amin(dest))
            dest = 255*(dest/np.amax(dest))
        return dest.reshape((self.height, self.width))
    
    def save_image(self, file):
        if ".bmdatga" in file or ".bGdata" in file:
            self.camera.SaveLoadData.SaveData(String(file), \
                                              UInt64(self.camera.FrameBuffer.Current),
                                              UInt64(1))
            return
        else:
            im = self.get_image()
            im = Image.fromarray(im.astype(np.int32))
            im.save(file)
            return

class BeamMic(Spiricon):
    def __init__(self, source_name="",window_name=""):
        if window_name == "":
            self.camera = AutomatedBeamMic("Beammic_Python", False)
        else:
            self.camera = AutomatedBeamMic(window_name.strip(), True)
            atexit.register(self.close)
            if source_name != "":
                self.set_source(source_name)
            self.start()
            return
class BeamGage(Spiricon):
    def __init__(self,source_name="",window_name=""):
        
        if window_name == "":
            self.camera = AutomatedBeamGage("BeamGage_Python", False)
        else:
            self.camera = AutomatedBeamGage(window_name.strip(), True)
        atexit.register(self.close)
        if source_name != "":
            print("Was here!")
            self.set_source(source_name)
        self.start()
        return
class RealtimeAxis_Camera(Thread):
    def __init__(self,
                 ax,
                 camera
                 ):
        super().__init__()
        self.ax = axself.camera = camera
        self.running = True
        
        self.I = self.camera.get_image()
        self.frame_time = time.time()
        self.fps = LW1050self.t_update = time.time()
        
        
        self.im = self.ax.imshow(self.camera.get_image(),
                                 vmin=0,
                                 vmax=2**12,
                                 interpolation="None",
                                 cmap='viridis')
        self.ax.axis('off')
        
        s="FPS: % 3.2f"% (self.fps)
        self.text = ax.text(0, 0,
                            s,
                            color='black',
                            horizontalalignment='left',
                            verticalalignment='bottom',
                            transform=ax.transAxes)
        return
    
    def __update__(self,
                   refresh_rate=30
                   ):
        tsleep = max(0,1/refresh_rate-(time.time()- self.t_update))
        time.sleep(tsleep)
        return
    
    def __refresh__(self):
        
        self.im.set_data(self.camera.get_image())
        
        window=10
        now = time.time()
        elapsed = now-self.frame_time
        self.frame_time = now
        self.fps = (1/(elapsed)+(window-1)*self.fps)/window
        
        s = "F{S: % 3.2f" % (self.fps)
        self.text.set_text(s)
        return
    
    def run(self):
        while self.running:
            self.__update__()
        return
    
if __name__=="__main__":
    
    cam_name = ""
    cam = BeamGage(cam_name, "PythonWindow")
            
