# -*- coding: utf-8 -*-
"""
Created on Wed Jul 19 20:18:20 2023

@author: ayras
"""

import sys
import matplotlib
matplotlib.use('Qt5Agg')

from PyQt5 import uic

from PyQt5.QtCore import QObject, QThread, QMutex, QMutexLocker, pyqtSignal as Signal
from PyQt5.QtGui import QPixmap, QImage, QBrush
from PyQt5.QtWidgets import (
    QApplication,
    QLabel,
    QMainWindow,
    QPushButton,
    QVBoxLayout,
    QGraphicsView,
    QGraphicsScene,
    QComboBox,
    QTextBrowser,
    QGraphicsPixmapItem)

from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from spiricon import BeamGage
from time import sleep
import numpy as np
from qimage2ndarray import array2qimage

mutex = QMutex()
frame_buffer = 0
frame_bool = True
class cameraWorker(QObject):
    progress = Signal()
    def __init__(self,camera = None):
        super(cameraWorker, self).__init__()
        self.camera = camera
    def run(self):
        """long-running task."""
        global frame_buffer
        global frame_bool
        while True:
            if frame_bool:
                sleep(.001)
                mutex.lock()
                self.camera.wait_one_frame()
                img = self.camera.get_image()
                
                frame_buffer = img
                #qImg = QPixmap(array2qimage(img))
                #frame_buffer = qImg
                
                mutex.unlock()
                self.progress.emit()

class GUI(QMainWindow):
    
    def __init__(self,*args,**kwargs):
        super(GUI, self).__init__(*args,**kwargs)
        uic.loadUi('gui.ui',self)
        width = 625
        height = 475
        self.setMaximumSize(width, height)
        self.setMinimumSize(width,height)
        self.setWindowTitle("Realtime BeamGage GUI")
        
        self.beamgage_bool = False
        
        
        self.get_start_capture = self.findChild(QPushButton,'imageStart')
        self.get_start_capture.clicked.connect(self.startCamera)
        
        self.get_stop_capture = self.findChild(QPushButton,'imageStop')
        self.get_stop_capture.clicked.connect(self.stopCamera)
        
        self.get_start_data = self.findChild(QPushButton,'resumeSim')
        self.get_stop_data = self.findChild(QPushButton,'stopSim')
        
        self.get_start_bg = self.findChild(QPushButton,'startBG')
        self.get_start_bg.clicked.connect(self.startBeamGage)
        
        self.get_stop_bg = self.findChild(QPushButton,'stopBG')
        
        
        self.get_console_text = self.findChild(QTextBrowser,'consoleBox')
        self.get_data_header = self.findChild(QLabel,'simulationHeader')
        self.get_image_header = self.findChild(QLabel,'imageHeader')
        self.get_console_header = self.findChild(QLabel,'consoleHeader')

        
        self.setStyleSheet("QLabel {font-weight: Bold;}")
        self.setStyleSheet("QMainWindow {background-color: silver;}")
        
        self.frame = self.findChild(QVBoxLayout, 'cameraBox')
        self.prep_plot()
        self.show()        
        
    def prep_plot(self):
        self.figure = Figure(frameon=False)
        self.canvas = FigureCanvas(self.figure)
        self.frame.addWidget(self.canvas)
        self.ax = self.figure.add_subplot(1,1,1)
        self.ax.set_xticks([])
        self.ax.set_yticks([])
        
        
    def update_plot(self):
        global frame_buffer
        global frame_bool
        if frame_bool:
            if mutex.tryLock():
                self.scene.addPixmap(frame_buffer)
                self.frame.show()
                mutex.unlock()
            else:
                return
    
    def update_plot2(self):
        global frame_buffer
        #global frame_bool
        #if frame_bool:
        if mutex.tryLock():
            self.ax.imshow(frame_buffer,aspect='auto')
            self.canvas.draw()
            mutex.unlock()
        else:
            return
        
    def startCamera(self):
        #global frame_bool
        if self.beamgage_bool:
            self.cameraThread = QThread()
            self.cameraworker = cameraWorker(camera = self.cam)
            self.cameraworker.moveToThread(self.cameraThread)
            self.cameraThread.started.connect(self.cameraworker.run)
            self.cameraThread.finished.connect(self.cameraThread.deleteLater)
            self.cameraworker.progress.connect(self.update_plot2)
            self.cameraThread.start()
            #global frame_bool
            frame_bool = True
            self.cam.start()
        else:
            self.get_console_text.setText("Please start BeamGage prior to initializing camera feed")
            self.get_console_text.setText("Please start BeamGage prior to initializing camera feed")
            self.get_console_text.setStylesheet("color: red;")
            
    def stopCamera(self):
        global frame_bool
        frame_bool = False
        self.cam.stop()
        
    def startBeamGage(self, cam_name=""):
        cam_name=""
        self.cam = BeamGage(cam_name, "PythonWindow")
        self.beamgage_bool = True
        return
                
    def closeEvent(self,event):
        if self.beamgage_bool == True:
            self.cameraThread.exit()
            self.cam.close()
            #QApplication.quit()

if __name__=="__main__":
    app = QApplication(sys.argv)
    w = GUI()
    w.show()
    app.exec_()
                    
                    